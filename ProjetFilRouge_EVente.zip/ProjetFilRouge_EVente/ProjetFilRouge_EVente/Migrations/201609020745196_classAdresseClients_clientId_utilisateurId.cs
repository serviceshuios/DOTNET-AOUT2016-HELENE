namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class classAdresseClients_clientId_utilisateurId : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.AdresseClients", "client_UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.AdresseClients", new[] { "client_UtilisateurId" });
            RenameColumn(table: "dbo.AdresseClients", name: "client_UtilisateurId", newName: "UtilisateurId");
            DropPrimaryKey("dbo.AdresseClients");
            AlterColumn("dbo.AdresseClients", "UtilisateurId", c => c.Int(nullable: false));
            AddPrimaryKey("dbo.AdresseClients", new[] { "AdresseId", "UtilisateurId" });
            CreateIndex("dbo.AdresseClients", "UtilisateurId");
            AddForeignKey("dbo.AdresseClients", "UtilisateurId", "dbo.Utilisateurs", "UtilisateurId", cascadeDelete: true);
            DropColumn("dbo.AdresseClients", "ClientId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.AdresseClients", "ClientId", c => c.Int(nullable: false));
            DropForeignKey("dbo.AdresseClients", "UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.AdresseClients", new[] { "UtilisateurId" });
            DropPrimaryKey("dbo.AdresseClients");
            AlterColumn("dbo.AdresseClients", "UtilisateurId", c => c.Int());
            AddPrimaryKey("dbo.AdresseClients", new[] { "AdresseId", "ClientId" });
            RenameColumn(table: "dbo.AdresseClients", name: "UtilisateurId", newName: "client_UtilisateurId");
            CreateIndex("dbo.AdresseClients", "client_UtilisateurId");
            AddForeignKey("dbo.AdresseClients", "client_UtilisateurId", "dbo.Utilisateurs", "UtilisateurId");
        }
    }
}
