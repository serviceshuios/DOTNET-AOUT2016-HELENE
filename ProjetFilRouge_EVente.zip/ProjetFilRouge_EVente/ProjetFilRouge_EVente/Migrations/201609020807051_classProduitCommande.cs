namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class classProduitCommande : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ProduitCommandes",
                c => new
                    {
                        ProduitId = c.Int(nullable: false),
                        CommandeId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.ProduitId, t.CommandeId })
                .ForeignKey("dbo.Commandes", t => t.CommandeId, cascadeDelete: true)
                .ForeignKey("dbo.Produits", t => t.ProduitId, cascadeDelete: true)
                .Index(t => t.ProduitId)
                .Index(t => t.CommandeId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ProduitCommandes", "ProduitId", "dbo.Produits");
            DropForeignKey("dbo.ProduitCommandes", "CommandeId", "dbo.Commandes");
            DropIndex("dbo.ProduitCommandes", new[] { "CommandeId" });
            DropIndex("dbo.ProduitCommandes", new[] { "ProduitId" });
            DropTable("dbo.ProduitCommandes");
        }
    }
}
