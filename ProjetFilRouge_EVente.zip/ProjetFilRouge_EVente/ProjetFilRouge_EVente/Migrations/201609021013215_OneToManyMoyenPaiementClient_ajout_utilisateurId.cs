namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class OneToManyMoyenPaiementClient_ajout_utilisateurId : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.MoyenPaiements", "client_UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.MoyenPaiements", new[] { "client_UtilisateurId" });
            RenameColumn(table: "dbo.MoyenPaiements", name: "client_UtilisateurId", newName: "UtilisateurId");
            AlterColumn("dbo.MoyenPaiements", "UtilisateurId", c => c.Int(nullable: false));
            CreateIndex("dbo.MoyenPaiements", "UtilisateurId");
            AddForeignKey("dbo.MoyenPaiements", "UtilisateurId", "dbo.Utilisateurs", "UtilisateurId", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.MoyenPaiements", "UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.MoyenPaiements", new[] { "UtilisateurId" });
            AlterColumn("dbo.MoyenPaiements", "UtilisateurId", c => c.Int());
            RenameColumn(table: "dbo.MoyenPaiements", name: "UtilisateurId", newName: "client_UtilisateurId");
            CreateIndex("dbo.MoyenPaiements", "client_UtilisateurId");
            AddForeignKey("dbo.MoyenPaiements", "client_UtilisateurId", "dbo.Utilisateurs", "UtilisateurId");
        }
    }
}
