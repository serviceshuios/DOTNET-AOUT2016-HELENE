namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class classClientMoyenPaiement : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.ClientMoyenPaiements", "client_UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.ClientMoyenPaiements", new[] { "client_UtilisateurId" });
            RenameColumn(table: "dbo.ClientMoyenPaiements", name: "client_UtilisateurId", newName: "UtilisateurId");
            DropPrimaryKey("dbo.ClientMoyenPaiements");
            AlterColumn("dbo.ClientMoyenPaiements", "UtilisateurId", c => c.Int(nullable: false));
            AddPrimaryKey("dbo.ClientMoyenPaiements", new[] { "UtilisateurId", "MoyenPaiementId" });
            CreateIndex("dbo.ClientMoyenPaiements", "UtilisateurId");
            AddForeignKey("dbo.ClientMoyenPaiements", "UtilisateurId", "dbo.Utilisateurs", "UtilisateurId", cascadeDelete: true);
            DropColumn("dbo.ClientMoyenPaiements", "ClientId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.ClientMoyenPaiements", "ClientId", c => c.Int(nullable: false));
            DropForeignKey("dbo.ClientMoyenPaiements", "UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.ClientMoyenPaiements", new[] { "UtilisateurId" });
            DropPrimaryKey("dbo.ClientMoyenPaiements");
            AlterColumn("dbo.ClientMoyenPaiements", "UtilisateurId", c => c.Int());
            AddPrimaryKey("dbo.ClientMoyenPaiements", new[] { "ClientId", "MoyenPaiementId" });
            RenameColumn(table: "dbo.ClientMoyenPaiements", name: "UtilisateurId", newName: "client_UtilisateurId");
            CreateIndex("dbo.ClientMoyenPaiements", "client_UtilisateurId");
            AddForeignKey("dbo.ClientMoyenPaiements", "client_UtilisateurId", "dbo.Utilisateurs", "UtilisateurId");
        }
    }
}
