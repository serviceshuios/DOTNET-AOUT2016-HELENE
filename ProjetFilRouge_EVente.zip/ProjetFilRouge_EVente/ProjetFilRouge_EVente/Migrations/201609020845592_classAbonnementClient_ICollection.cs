namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class classAbonnementClient_ICollection : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Fidelites", "UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.Fidelites", new[] { "UtilisateurId" });
            CreateTable(
                "dbo.FideliteClients",
                c => new
                    {
                        FideliteId = c.Int(nullable: false),
                        UtilisateurId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.FideliteId, t.UtilisateurId })
                .ForeignKey("dbo.Utilisateurs", t => t.UtilisateurId, cascadeDelete: true)
                .ForeignKey("dbo.Fidelites", t => t.FideliteId, cascadeDelete: true)
                .Index(t => t.FideliteId)
                .Index(t => t.UtilisateurId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.FideliteClients", "FideliteId", "dbo.Fidelites");
            DropForeignKey("dbo.FideliteClients", "UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.FideliteClients", new[] { "UtilisateurId" });
            DropIndex("dbo.FideliteClients", new[] { "FideliteId" });
            DropTable("dbo.FideliteClients");
            CreateIndex("dbo.Fidelites", "UtilisateurId");
            AddForeignKey("dbo.Fidelites", "UtilisateurId", "dbo.Utilisateurs", "UtilisateurId", cascadeDelete: true);
        }
    }
}
