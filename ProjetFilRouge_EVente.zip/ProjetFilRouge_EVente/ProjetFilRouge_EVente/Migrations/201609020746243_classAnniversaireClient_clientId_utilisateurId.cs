namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class classAnniversaireClient_clientId_utilisateurId : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.AnniversaireClients", "client_UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.AnniversaireClients", new[] { "client_UtilisateurId" });
            RenameColumn(table: "dbo.AnniversaireClients", name: "client_UtilisateurId", newName: "UtilisateurId");
            DropPrimaryKey("dbo.AnniversaireClients");
            AlterColumn("dbo.AnniversaireClients", "UtilisateurId", c => c.Int(nullable: false));
            AddPrimaryKey("dbo.AnniversaireClients", new[] { "AnniversaireId", "UtilisateurId" });
            CreateIndex("dbo.AnniversaireClients", "UtilisateurId");
            AddForeignKey("dbo.AnniversaireClients", "UtilisateurId", "dbo.Utilisateurs", "UtilisateurId", cascadeDelete: true);
            DropColumn("dbo.AnniversaireClients", "ClientId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.AnniversaireClients", "ClientId", c => c.Int(nullable: false));
            DropForeignKey("dbo.AnniversaireClients", "UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.AnniversaireClients", new[] { "UtilisateurId" });
            DropPrimaryKey("dbo.AnniversaireClients");
            AlterColumn("dbo.AnniversaireClients", "UtilisateurId", c => c.Int());
            AddPrimaryKey("dbo.AnniversaireClients", new[] { "AnniversaireId", "ClientId" });
            RenameColumn(table: "dbo.AnniversaireClients", name: "UtilisateurId", newName: "client_UtilisateurId");
            CreateIndex("dbo.AnniversaireClients", "client_UtilisateurId");
            AddForeignKey("dbo.AnniversaireClients", "client_UtilisateurId", "dbo.Utilisateurs", "UtilisateurId");
        }
    }
}
