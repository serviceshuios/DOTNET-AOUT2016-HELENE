namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ClassProduit : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Produits",
                c => new
                    {
                        ProduitId = c.Int(nullable: false, identity: true),
                        Nom = c.String(),
                        Categorie = c.String(),
                        Prix = c.Decimal(nullable: false, storeType: "money"),
                        Stock = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ProduitId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Produits");
        }
    }
}
