namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class OneToManyMoyenPaiementClient : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.ClientMoyenPaiements", "UtilisateurId", "dbo.Utilisateurs");
            DropForeignKey("dbo.ClientMoyenPaiements", "MoyenPaiementId", "dbo.MoyenPaiements");
            DropIndex("dbo.ClientMoyenPaiements", new[] { "UtilisateurId" });
            DropIndex("dbo.ClientMoyenPaiements", new[] { "MoyenPaiementId" });
            AddColumn("dbo.MoyenPaiements", "client_UtilisateurId", c => c.Int());
            CreateIndex("dbo.MoyenPaiements", "client_UtilisateurId");
            AddForeignKey("dbo.MoyenPaiements", "client_UtilisateurId", "dbo.Utilisateurs", "UtilisateurId");
            DropTable("dbo.ClientMoyenPaiements");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.ClientMoyenPaiements",
                c => new
                    {
                        UtilisateurId = c.Int(nullable: false),
                        MoyenPaiementId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.UtilisateurId, t.MoyenPaiementId });
            
            DropForeignKey("dbo.MoyenPaiements", "client_UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.MoyenPaiements", new[] { "client_UtilisateurId" });
            DropColumn("dbo.MoyenPaiements", "client_UtilisateurId");
            CreateIndex("dbo.ClientMoyenPaiements", "MoyenPaiementId");
            CreateIndex("dbo.ClientMoyenPaiements", "UtilisateurId");
            AddForeignKey("dbo.ClientMoyenPaiements", "MoyenPaiementId", "dbo.MoyenPaiements", "MoyenPaiementId", cascadeDelete: true);
            AddForeignKey("dbo.ClientMoyenPaiements", "UtilisateurId", "dbo.Utilisateurs", "UtilisateurId", cascadeDelete: true);
        }
    }
}
