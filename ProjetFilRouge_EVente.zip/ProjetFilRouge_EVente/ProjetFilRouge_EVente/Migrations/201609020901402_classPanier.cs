namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class classPanier : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.ProduitCommandes", "PanierId", c => c.Int(nullable: false));
            CreateIndex("dbo.ProduitCommandes", "PanierId");
            AddForeignKey("dbo.ProduitCommandes", "PanierId", "dbo.Paniers", "PanierId", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ProduitCommandes", "PanierId", "dbo.Paniers");
            DropIndex("dbo.ProduitCommandes", new[] { "PanierId" });
            DropColumn("dbo.ProduitCommandes", "PanierId");
        }
    }
}
