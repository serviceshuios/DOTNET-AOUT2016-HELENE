namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class classAvis_clientId_utilisateurId : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Avis_ClientProduit", "client_UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.Avis_ClientProduit", new[] { "client_UtilisateurId" });
            RenameColumn(table: "dbo.Avis_ClientProduit", name: "client_UtilisateurId", newName: "UtilisateurId");
            DropPrimaryKey("dbo.Avis_ClientProduit");
            AlterColumn("dbo.Avis_ClientProduit", "UtilisateurId", c => c.Int(nullable: false));
            AddPrimaryKey("dbo.Avis_ClientProduit", new[] { "UtilisateurId", "ProduitId" });
            CreateIndex("dbo.Avis_ClientProduit", "UtilisateurId");
            AddForeignKey("dbo.Avis_ClientProduit", "UtilisateurId", "dbo.Utilisateurs", "UtilisateurId", cascadeDelete: true);
            DropColumn("dbo.Avis_ClientProduit", "ClientId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Avis_ClientProduit", "ClientId", c => c.Int(nullable: false));
            DropForeignKey("dbo.Avis_ClientProduit", "UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.Avis_ClientProduit", new[] { "UtilisateurId" });
            DropPrimaryKey("dbo.Avis_ClientProduit");
            AlterColumn("dbo.Avis_ClientProduit", "UtilisateurId", c => c.Int());
            AddPrimaryKey("dbo.Avis_ClientProduit", new[] { "ClientId", "ProduitId" });
            RenameColumn(table: "dbo.Avis_ClientProduit", name: "UtilisateurId", newName: "client_UtilisateurId");
            CreateIndex("dbo.Avis_ClientProduit", "client_UtilisateurId");
            AddForeignKey("dbo.Avis_ClientProduit", "client_UtilisateurId", "dbo.Utilisateurs", "UtilisateurId");
        }
    }
}
