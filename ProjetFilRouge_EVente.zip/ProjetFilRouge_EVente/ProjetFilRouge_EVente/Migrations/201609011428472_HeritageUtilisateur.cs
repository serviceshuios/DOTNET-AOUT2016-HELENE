namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class HeritageUtilisateur : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Utilisateurs", "NumeroTelephone", c => c.String());
            AddColumn("dbo.Utilisateurs", "DateNaissance", c => c.DateTime());
            AddColumn("dbo.Utilisateurs", "Actif", c => c.Boolean());
            AddColumn("dbo.Utilisateurs", "NumeroCarteFidelite", c => c.Int());
            AddColumn("dbo.Utilisateurs", "NombrePoints", c => c.Int());
            AddColumn("dbo.Utilisateurs", "CompteASupprimer", c => c.Boolean());
            AddColumn("dbo.Utilisateurs", "Discriminator", c => c.String(nullable: false, maxLength: 128));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Utilisateurs", "Discriminator");
            DropColumn("dbo.Utilisateurs", "CompteASupprimer");
            DropColumn("dbo.Utilisateurs", "NombrePoints");
            DropColumn("dbo.Utilisateurs", "NumeroCarteFidelite");
            DropColumn("dbo.Utilisateurs", "Actif");
            DropColumn("dbo.Utilisateurs", "DateNaissance");
            DropColumn("dbo.Utilisateurs", "NumeroTelephone");
        }
    }
}
