namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AjoutLigneProduitCommande : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.ProduitCommandes", "quantite", c => c.Int(nullable: false));
            AddColumn("dbo.ProduitCommandes", "promotion", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.ProduitCommandes", "promotion");
            DropColumn("dbo.ProduitCommandes", "quantite");
        }
    }
}
