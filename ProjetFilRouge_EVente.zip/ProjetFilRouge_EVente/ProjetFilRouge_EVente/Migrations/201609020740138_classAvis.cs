namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class classAvis : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Avis_ClientProduit",
                c => new
                    {
                        ClientId = c.Int(nullable: false),
                        ProduitId = c.Int(nullable: false),
                        Note = c.Single(nullable: false),
                        Commentaire = c.String(),
                        client_UtilisateurId = c.Int(),
                    })
                .PrimaryKey(t => new { t.ClientId, t.ProduitId })
                .ForeignKey("dbo.Utilisateurs", t => t.client_UtilisateurId)
                .ForeignKey("dbo.Produits", t => t.ProduitId, cascadeDelete: true)
                .Index(t => t.ProduitId)
                .Index(t => t.client_UtilisateurId);
            
            CreateTable(
                "dbo.Commandes",
                c => new
                    {
                        CommandeId = c.Int(nullable: false, identity: true),
                        Commentaire = c.String(),
                        UtilisateurId = c.Int(nullable: false),
                        StatutCommandeId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.CommandeId)
                .ForeignKey("dbo.Utilisateurs", t => t.UtilisateurId, cascadeDelete: true)
                .ForeignKey("dbo.StatutCommandes", t => t.StatutCommandeId, cascadeDelete: true)
                .Index(t => t.UtilisateurId)
                .Index(t => t.StatutCommandeId);
            
            CreateTable(
                "dbo.StatutCommandes",
                c => new
                    {
                        StatutCommandeId = c.Int(nullable: false, identity: true),
                        typeCommande = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.StatutCommandeId);
            
            CreateTable(
                "dbo.Fidelites",
                c => new
                    {
                        FideliteId = c.Int(nullable: false, identity: true),
                        NombrePoints = c.Int(nullable: false),
                        Avantages = c.String(),
                        UtilisateurId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.FideliteId)
                .ForeignKey("dbo.Utilisateurs", t => t.UtilisateurId, cascadeDelete: true)
                .Index(t => t.UtilisateurId);
            
            CreateTable(
                "dbo.Historique_UtilisateurProduit",
                c => new
                    {
                        UtilisateurId = c.Int(nullable: false),
                        ProduitId = c.Int(nullable: false),
                        DateConsultation = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => new { t.UtilisateurId, t.ProduitId })
                .ForeignKey("dbo.Produits", t => t.ProduitId, cascadeDelete: true)
                .ForeignKey("dbo.Utilisateurs", t => t.UtilisateurId, cascadeDelete: true)
                .Index(t => t.UtilisateurId)
                .Index(t => t.ProduitId);
            
            CreateTable(
                "dbo.Catalogues",
                c => new
                    {
                        CatalogueId = c.Int(nullable: false, identity: true),
                    })
                .PrimaryKey(t => t.CatalogueId);
            
            CreateTable(
                "dbo.Promotions",
                c => new
                    {
                        PromotionId = c.Int(nullable: false, identity: true),
                        ProduitId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.PromotionId)
                .ForeignKey("dbo.Produits", t => t.ProduitId, cascadeDelete: true)
                .Index(t => t.ProduitId);
            
            AddColumn("dbo.Produits", "CatalogueId", c => c.Int(nullable: false));
            CreateIndex("dbo.Produits", "CatalogueId");
            AddForeignKey("dbo.Produits", "CatalogueId", "dbo.Catalogues", "CatalogueId", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Historique_UtilisateurProduit", "UtilisateurId", "dbo.Utilisateurs");
            DropForeignKey("dbo.Promotions", "ProduitId", "dbo.Produits");
            DropForeignKey("dbo.Historique_UtilisateurProduit", "ProduitId", "dbo.Produits");
            DropForeignKey("dbo.Produits", "CatalogueId", "dbo.Catalogues");
            DropForeignKey("dbo.Avis_ClientProduit", "ProduitId", "dbo.Produits");
            DropForeignKey("dbo.Fidelites", "UtilisateurId", "dbo.Utilisateurs");
            DropForeignKey("dbo.Commandes", "StatutCommandeId", "dbo.StatutCommandes");
            DropForeignKey("dbo.Commandes", "UtilisateurId", "dbo.Utilisateurs");
            DropForeignKey("dbo.Avis_ClientProduit", "client_UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.Promotions", new[] { "ProduitId" });
            DropIndex("dbo.Produits", new[] { "CatalogueId" });
            DropIndex("dbo.Historique_UtilisateurProduit", new[] { "ProduitId" });
            DropIndex("dbo.Historique_UtilisateurProduit", new[] { "UtilisateurId" });
            DropIndex("dbo.Fidelites", new[] { "UtilisateurId" });
            DropIndex("dbo.Commandes", new[] { "StatutCommandeId" });
            DropIndex("dbo.Commandes", new[] { "UtilisateurId" });
            DropIndex("dbo.Avis_ClientProduit", new[] { "client_UtilisateurId" });
            DropIndex("dbo.Avis_ClientProduit", new[] { "ProduitId" });
            DropColumn("dbo.Produits", "CatalogueId");
            DropTable("dbo.Promotions");
            DropTable("dbo.Catalogues");
            DropTable("dbo.Historique_UtilisateurProduit");
            DropTable("dbo.Fidelites");
            DropTable("dbo.StatutCommandes");
            DropTable("dbo.Commandes");
            DropTable("dbo.Avis_ClientProduit");
        }
    }
}
