namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class civiliteClient : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Utilisateurs", "civilite", c => c.Int());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Utilisateurs", "civilite");
        }
    }
}
