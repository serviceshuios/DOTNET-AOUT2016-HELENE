namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class classAbonnementClients_clientId_utilisateurId : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.AbonnementClients", "client_UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.AbonnementClients", new[] { "client_UtilisateurId" });
            RenameColumn(table: "dbo.AbonnementClients", name: "client_UtilisateurId", newName: "UtilisateurId");
            DropPrimaryKey("dbo.AbonnementClients");
            AlterColumn("dbo.AbonnementClients", "UtilisateurId", c => c.Int(nullable: false));
            AddPrimaryKey("dbo.AbonnementClients", new[] { "AbonnementId", "UtilisateurId" });
            CreateIndex("dbo.AbonnementClients", "UtilisateurId");
            AddForeignKey("dbo.AbonnementClients", "UtilisateurId", "dbo.Utilisateurs", "UtilisateurId", cascadeDelete: true);
            DropColumn("dbo.AbonnementClients", "ClientId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.AbonnementClients", "ClientId", c => c.Int(nullable: false));
            DropForeignKey("dbo.AbonnementClients", "UtilisateurId", "dbo.Utilisateurs");
            DropIndex("dbo.AbonnementClients", new[] { "UtilisateurId" });
            DropPrimaryKey("dbo.AbonnementClients");
            AlterColumn("dbo.AbonnementClients", "UtilisateurId", c => c.Int());
            AddPrimaryKey("dbo.AbonnementClients", new[] { "AbonnementId", "ClientId" });
            RenameColumn(table: "dbo.AbonnementClients", name: "UtilisateurId", newName: "client_UtilisateurId");
            CreateIndex("dbo.AbonnementClients", "client_UtilisateurId");
            AddForeignKey("dbo.AbonnementClients", "client_UtilisateurId", "dbo.Utilisateurs", "UtilisateurId");
        }
    }
}
