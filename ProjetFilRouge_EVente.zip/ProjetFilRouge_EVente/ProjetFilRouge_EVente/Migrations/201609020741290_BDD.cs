namespace ProjetFilRouge_EVente.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class BDD : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.AbonnementClients",
                c => new
                    {
                        AbonnementId = c.Int(nullable: false),
                        ClientId = c.Int(nullable: false),
                        client_UtilisateurId = c.Int(),
                    })
                .PrimaryKey(t => new { t.AbonnementId, t.ClientId })
                .ForeignKey("dbo.Abonnements", t => t.AbonnementId, cascadeDelete: true)
                .ForeignKey("dbo.Utilisateurs", t => t.client_UtilisateurId)
                .Index(t => t.AbonnementId)
                .Index(t => t.client_UtilisateurId);
            
            CreateTable(
                "dbo.Abonnements",
                c => new
                    {
                        AbonnementId = c.Int(nullable: false, identity: true),
                        Nom = c.String(),
                        DateDebut = c.DateTime(nullable: false),
                        Duree = c.DateTime(nullable: false),
                        DateFin = c.DateTime(nullable: false),
                        Prix = c.Decimal(nullable: false, storeType: "money"),
                    })
                .PrimaryKey(t => t.AbonnementId);
            
            CreateTable(
                "dbo.AdresseClients",
                c => new
                    {
                        AdresseId = c.Int(nullable: false),
                        ClientId = c.Int(nullable: false),
                        client_UtilisateurId = c.Int(),
                    })
                .PrimaryKey(t => new { t.AdresseId, t.ClientId })
                .ForeignKey("dbo.Adresses", t => t.AdresseId, cascadeDelete: true)
                .ForeignKey("dbo.Utilisateurs", t => t.client_UtilisateurId)
                .Index(t => t.AdresseId)
                .Index(t => t.client_UtilisateurId);
            
            CreateTable(
                "dbo.Adresses",
                c => new
                    {
                        AdresseId = c.Int(nullable: false, identity: true),
                        NumeroRue = c.String(),
                        NomRue = c.String(),
                        CodePostal = c.String(),
                        Ville = c.String(),
                        typeadresse = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.AdresseId);
            
            CreateTable(
                "dbo.AnniversaireClients",
                c => new
                    {
                        AnniversaireId = c.Int(nullable: false),
                        ClientId = c.Int(nullable: false),
                        client_UtilisateurId = c.Int(),
                    })
                .PrimaryKey(t => new { t.AnniversaireId, t.ClientId })
                .ForeignKey("dbo.Anniversaires", t => t.AnniversaireId, cascadeDelete: true)
                .ForeignKey("dbo.Utilisateurs", t => t.client_UtilisateurId)
                .Index(t => t.AnniversaireId)
                .Index(t => t.client_UtilisateurId);
            
            CreateTable(
                "dbo.Anniversaires",
                c => new
                    {
                        AnniversaireId = c.Int(nullable: false, identity: true),
                        Actif = c.Boolean(nullable: false),
                        Utilise = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.AnniversaireId);
            
            CreateTable(
                "dbo.MoyenPaiements",
                c => new
                    {
                        MoyenPaiementId = c.Int(nullable: false, identity: true),
                        typePaiement = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.MoyenPaiementId);
            
            CreateTable(
                "dbo.PanierProduits",
                c => new
                    {
                        PanierId = c.Int(nullable: false),
                        ProduitId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.PanierId, t.ProduitId })
                .ForeignKey("dbo.Paniers", t => t.PanierId, cascadeDelete: true)
                .ForeignKey("dbo.Produits", t => t.ProduitId, cascadeDelete: true)
                .Index(t => t.PanierId)
                .Index(t => t.ProduitId);
            
            CreateTable(
                "dbo.Paniers",
                c => new
                    {
                        PanierId = c.Int(nullable: false, identity: true),
                        NombreProduits = c.Int(nullable: false),
                        Prixtotal = c.Decimal(nullable: false, storeType: "money"),
                    })
                .PrimaryKey(t => t.PanierId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.PanierProduits", "ProduitId", "dbo.Produits");
            DropForeignKey("dbo.PanierProduits", "PanierId", "dbo.Paniers");
            DropForeignKey("dbo.AnniversaireClients", "client_UtilisateurId", "dbo.Utilisateurs");
            DropForeignKey("dbo.AnniversaireClients", "AnniversaireId", "dbo.Anniversaires");
            DropForeignKey("dbo.AdresseClients", "client_UtilisateurId", "dbo.Utilisateurs");
            DropForeignKey("dbo.AdresseClients", "AdresseId", "dbo.Adresses");
            DropForeignKey("dbo.AbonnementClients", "client_UtilisateurId", "dbo.Utilisateurs");
            DropForeignKey("dbo.AbonnementClients", "AbonnementId", "dbo.Abonnements");
            DropIndex("dbo.PanierProduits", new[] { "ProduitId" });
            DropIndex("dbo.PanierProduits", new[] { "PanierId" });
            DropIndex("dbo.AnniversaireClients", new[] { "client_UtilisateurId" });
            DropIndex("dbo.AnniversaireClients", new[] { "AnniversaireId" });
            DropIndex("dbo.AdresseClients", new[] { "client_UtilisateurId" });
            DropIndex("dbo.AdresseClients", new[] { "AdresseId" });
            DropIndex("dbo.AbonnementClients", new[] { "client_UtilisateurId" });
            DropIndex("dbo.AbonnementClients", new[] { "AbonnementId" });
            DropTable("dbo.Paniers");
            DropTable("dbo.PanierProduits");
            DropTable("dbo.MoyenPaiements");
            DropTable("dbo.Anniversaires");
            DropTable("dbo.AnniversaireClients");
            DropTable("dbo.Adresses");
            DropTable("dbo.AdresseClients");
            DropTable("dbo.Abonnements");
            DropTable("dbo.AbonnementClients");
        }
    }
}
