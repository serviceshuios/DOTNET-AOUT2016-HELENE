﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetFilRouge_EVente.Metier
{
    public class Client : Utilisateur
    {
        public DateTime DateNaissance { get; set; }
        public char Sexe { get; set; }
        public bool Actif { get; set; }
        public int NumeroCarteFidelite { get; set; }
        public int NombrePoints { get; set; }
        public bool CompteASupprimer { get; set; }
        public enum Civilite { Mademoiselle, Madame, Monsieur};
        public Civilite civilite { get; set; }

        public virtual ICollection<Commande> commandes { get; set; }

        public virtual ICollection<FideliteClient> clientFidelités { get; set; }
        public virtual ICollection<Avis_ClientProduit> avis_clientProduit { get; set; }
        public virtual ICollection<AnniversaireClient> clientAnniversaires { get; set; }
        public virtual ICollection<AdresseClient> clientAdresses { get; set; }
        public virtual ICollection<AbonnementClient> clientAbonnements { get; set; }
        public virtual ICollection<MoyenPaiement> moyenPaiements { get; set; }
    }
}
