﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetFilRouge_EVente.Metier
{
    public class PanierProduit
    {
        [Key, Column(Order=0)]
        public int PanierId {get; set;}
        [Key, Column(Order = 1)]
        public int ProduitId { get; set; }

        public virtual Panier panier { get; set; }
        public virtual Produit produit { get; set; }
    }
}
