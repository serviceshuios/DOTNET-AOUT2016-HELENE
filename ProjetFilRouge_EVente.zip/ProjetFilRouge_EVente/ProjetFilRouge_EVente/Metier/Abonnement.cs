﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetFilRouge_EVente.Metier
{
    public class Abonnement
    {
        public int AbonnementId { get; set; }
        public string Nom { get; set; }
        public DateTime DateDebut { get; set; }
        public DateTime Duree { get; set; }
        public DateTime DateFin { get; set; }
        [Column("Prix", TypeName = "money")]
        public decimal Prix { get; set; }

        public virtual ICollection<AbonnementClient> abonnementClients { get; set; }
    }
}
