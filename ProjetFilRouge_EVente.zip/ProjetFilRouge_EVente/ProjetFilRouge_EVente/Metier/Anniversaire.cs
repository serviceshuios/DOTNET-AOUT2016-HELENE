﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetFilRouge_EVente.Metier
{
    public class Anniversaire
    {
        public int AnniversaireId { get; set; }
        public bool Actif { get; set; }
        public bool Utilise { get; set; }

        public virtual ICollection<AnniversaireClient> anniversaireClients { get; set; }
    }
}
