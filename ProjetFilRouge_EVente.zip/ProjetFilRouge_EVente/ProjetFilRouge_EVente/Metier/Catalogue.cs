﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetFilRouge_EVente.Metier
{
    public class Catalogue
    {
        public int CatalogueId { get; set; }
        public virtual ICollection<Produit> produits { get; set; }
    }
}
