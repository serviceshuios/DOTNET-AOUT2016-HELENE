﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetFilRouge_EVente.Metier
{
    public class Utilisateur
    {
        public int UtilisateurId { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public string Email { get; set; }
        public bool DroitAcces { get; set; }

        public virtual ICollection<Historique_UtilisateurProduit> historiques_UtilisateurProduit { get; set; }
    }
}
