﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetFilRouge_EVente.Metier
{
    public class Administrateur: Utilisateur
    {
        public string NumeroTelephone { get; set; }

    }
}
