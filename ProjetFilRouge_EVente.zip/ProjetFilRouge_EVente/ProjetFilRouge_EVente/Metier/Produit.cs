﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetFilRouge_EVente.Metier
{
    public class Produit
    {
        public int ProduitId { get; set; }
        public string Nom { get; set; }
        public string Categorie { get; set; }
        [Column("Prix", TypeName = "money")]
        public decimal Prix { get; set; }
        public int Stock { get; set; }

        public int CatalogueId { get; set; }
        public virtual Catalogue catalogue { get; set; }

        public virtual ICollection<Promotion> promotions { get; set; }
        public virtual ICollection<Historique_UtilisateurProduit> historiques_ProduitUtilisateur { get; set; }
        public virtual ICollection<Avis_ClientProduit> avis_produitClient { get; set; }
        public virtual ICollection<ProduitCommande> produitCommande { get; set; }
        
    }
}
