﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetFilRouge_EVente.Metier
{
    public class Commande
    {
        public int CommandeId { get; set; }
        public string Commentaire { get; set; }
        public int UtilisateurId { get; set; }

        public virtual Client client { get; set; }
        public int StatutCommandeId { get; set; }
        public virtual StatutCommande statut { get; set; }

        public virtual ICollection<ProduitCommande> comandeProduits { get; set; }
    }
}
