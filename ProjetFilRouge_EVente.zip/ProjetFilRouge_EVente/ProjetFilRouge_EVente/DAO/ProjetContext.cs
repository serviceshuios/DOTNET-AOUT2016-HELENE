﻿using ProjetFilRouge_EVente.Metier;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetFilRouge_EVente.DAO
{
    public class ProjetContext : DbContext
    {
        public DbSet<Utilisateur> utilisateurs { get; set; }
        public DbSet<Produit> produits { get; set; }
        public DbSet<Avis_ClientProduit> avis_ClientProduit { get; set; }
        public DbSet<Historique_UtilisateurProduit> historique_UtilisateurProduit { get; set; }
        public DbSet<Abonnement> abonnements { get; set; }
        public DbSet<AbonnementClient> abonnementClients { get; set; }
        public DbSet<Adresse> adresses { get; set; }
        public DbSet<AdresseClient> adresseClients { get; set; }
        public DbSet<Anniversaire> anniversaires { get; set; }
        public DbSet<AnniversaireClient> aniversaireClients { get; set; }
        public DbSet<Catalogue> calatogues { get; set; }
        public DbSet<Commande> commandes { get; set; }
        public DbSet<StatutCommande> statutCommandes { get; set; }
        public DbSet<Fidelite> fidelites { get; set; }
        public DbSet<MoyenPaiement> moyenPaiement { get; set; }
        //public DbSet<ClientMoyenPaiement> clientMoyenPaiements { get; set; }
        public DbSet<Panier> paniers { get; set; }
        public DbSet<ProduitCommande> Produitcommande { get; set; }
        public DbSet<Promotion> promotions { get; set; }
        public DbSet<PanierProduit> panierproduits { get; set; }
        public DbSet<FideliteClient> fideliteClients { get; set; }

    }
}
